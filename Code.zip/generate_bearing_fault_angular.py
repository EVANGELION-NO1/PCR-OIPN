
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert
from scipy.fft import fft, fftfreq
from data_set import DatasetConfig
import numpy as np
from scipy.signal import hilbert
from scipy.fft import fft, fftfreq
from data_set import *
import numpy as np
from scipy.signal.windows import gaussian
from scipy.optimize import curve_fit
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert, find_peaks  # 这里添加 find_peaks
from scipy.fft import fft, fftfreq


def create_rectangular_window(orders_axis, center_freq, impulse_width):
    """创建矩形窗"""

    if impulse_width <= 0:
        return np.array([]), 0, 0

    # 直接使用impulse_width作为矩形窗宽度
    win_length = int(impulse_width)
    if win_length < 1:
        return np.array([]), 0, 0

    # 创建矩形窗 (所有值设为1)
    rect_win = np.ones(win_length)

    idx = np.argmin(np.abs(orders_axis - center_freq))

    # 计算有效范围
    start = max(0, idx - win_length // 2)
    end = min(len(orders_axis), start + win_length)

    # 检查有效性
    if start >= end:
        return np.array([]), 0, 0

    # 截断窗口适应边界
    actual_length = end - start
    if actual_length < win_length:
        rect_win = rect_win[:actual_length]

    return rect_win, start, end


def generate_adaptive_masks(real_data, orders_axis, fault_harmonics):
    """生成掩码（安全增强版）"""
    masks = {}
    window_metadata = {}
    fault_orders = real_data['fault_orders']

    # 定义需要调制边频的故障类型
    modulated_faults = ['BPFI', 'BSF']  # BPFO不生成边频带

    ##############################################################################################################################
    impulse_width = 24  #设置冲击宽度
    print('当前设置冲击宽度为'+str(impulse_width))

    for fault_type, order in fault_orders.items():
        if fault_type == 'normal':
            masks[fault_type] = np.zeros_like(orders_axis)
            window_metadata[fault_type] = []
            continue

        max_harmonics = fault_harmonics.get(fault_type, 0)
        if max_harmonics <= 0:
            masks[fault_type] = np.zeros_like(orders_axis)
            window_metadata[fault_type] = []
            continue

        mask = np.zeros_like(orders_axis)
        window_list = []

        for h in range(1, max_harmonics + 1):
            center = order * h
            if center < orders_axis[0] or center > orders_axis[-1]:
                continue

            # 生成主峰窗口
            gauss, start, end = create_rectangular_window(orders_axis, center, impulse_width)
            if len(gauss) == 0:
                continue

            # 更新掩码和元数据
            mask[start:end] = np.maximum(mask[start:end], gauss)
            window_list.append({
                'type': 'main',
                'harmonic': h,
                'center': center,
                'start': start,
                'end': end,
                'width': impulse_width
            })

            # ==== 仅在需要调制的故障类型生成边频带 ====
            if fault_type not in modulated_faults:
                continue

            # 生成边带（示例：±1阶转频）
            for sideband_offset in [-1, 1]:
                side_center = center + sideband_offset * 1  # 假设转频为1阶
                gauss_side, start_side, end_side = create_rectangular_window(orders_axis, side_center, impulse_width)
                if len(gauss_side) == 0:
                    continue

                mask[start_side:end_side] = np.maximum(mask[start_side:end_side], gauss_side)
                window_list.append({
                    'type': 'sideband',
                    'harmonic': h,
                    'center': side_center,
                    'start': start_side,
                    'end': end_side,
                    'width': impulse_width
                })

        masks[fault_type] = mask
        window_metadata[fault_type] = window_list

    return masks, window_metadata




def apply_advanced_masking(real_dataset, fault_harmonics, mask_type):

    orders_axis = real_dataset['orders_axis']
    masks, window_metadata = generate_adaptive_masks(real_dataset, orders_axis, fault_harmonics)

    cf_dataset = {
        'train': {'angular_freq': np.copy(real_dataset['train']['angular_freq']),
                  'labels': real_dataset['train']['labels']},
        'test': {'angular_freq': np.copy(real_dataset['test']['angular_freq']),
                 'labels': real_dataset['test']['labels']},
        'orders_axis': orders_axis
    }

    '''反事实故障样本生成'''
    for subset in ['train', 'test']:
        for i in range(len(cf_dataset[subset]['angular_freq'])):
            spectrum = cf_dataset[subset]['angular_freq'][i]
            label = cf_dataset[subset]['labels'][i]
            fault_type = list(real_dataset['fault_orders'].keys())[label]

            if fault_type == 'normal' or fault_type not in fault_harmonics:
                continue

            mask = masks[fault_type]
            if mask.sum() == 0:
                continue

            if mask_type == 'zero':
                spectrum[mask > 0] = 0

    return cf_dataset
