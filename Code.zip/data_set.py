
import scipy.io as sio
from scipy import signal
import os
import numpy as np
from pathlib import Path
from scipy.interpolate import interp1d


class DatasetConfig:
    """参数配置工厂"""
    _presets = {
        'CWRU': {
            'resample_enabled': False,  # bool: 是否启用降采样，要是是False就不用管下面两个参数
            'cycle_length': 2048,  # 单个样本采样长度
            'target_length': 1024,  # 降采样后单个样本长度

            'time_window_size': 2048,  # 时域窗口样本尺寸
            'time_step_size': 256,     # 时域窗口滑窗步长

            'freq_window_size': 10240*2,  # 频域窗口样本尺寸
            'freq_step_size': 256,     # 频域窗口滑窗步长

            'total_samples': 200,  # 单类别总样本量
            'train_per_class': 100,  # 单类别训练样本量
            'test_per_class': 100,  # 单类别测试样本量

            'norm_type': 'minmax',  # 时域样本归一化方式：可选 'z-score'/'minmax'/'none'
            'window_type': 'none',  # 时域样本加窗方式：可选 'hann'/'hamming'/'none'

            'freq_analysis_type': 'envelope',  # 频域样本类型选择：可选'magnitude'常规幅度谱/'envelope'包络谱/'cepstrum'倒频谱
            'freq_norm_type': 'minmax',  # 频域样本归一化方式：可选 'z-score'/'minmax'/'none'
            'cepstrum_lifter': 0.8,  # 控制倒频谱的平滑程度，范围0-1（值越大，保留的低频成分越多）
            'sampling_rate': 12000,  # 信号的采样率（单位：Hz），要是降采样了要重新算一下

            'angular_resample_enabled': True,
            'angular_window_revs': 40,      # 角域窗口覆盖的圈数
            'angular_samples_per_rev': 1024,  # 每圈样本数
            'angular_step_revs': 1.0,         # 滑窗步长（圈数）
            'angular_norm_type': 'minmax',  # 角域样本归一化方式：可选 'z-score'/'minmax'/'none'

            'angular_freq_analysis_type': 'envelope',  # 角域频谱类型,# 频域样本类型选择：可选'magnitude'常规幅度谱/'envelope'包络谱
            'angular_freq_norm_type': 'none',  # 角域频谱样本归一化方式：可选 'z-score'/'minmax'/'none'

            'random_seed': 42,  # 新增：随机数种子
            'shuffle_split': True,  # 新增：是否随机划分训练测试集
            'shuffle_final': False,  # 新增：是否全局打乱训练集
            'save_path': './datasets/cached_CWRU/',  # 数据保存路径
            'use_cached': False,  # 是否使用原来的缓存

            'bearing_params': {  # mm,6205
                'inner_diameter': 25.0,
                'outer_diameter': 52.0,
                'ball_diameter': 7.94,
                'number_balls': 9,
                'contact_angle': 0
            },
        },

        'HNUST_6205': {
            'resample_enabled': False,  # bool: 是否启用降采样，要是是False就不用管下面两个参数
            'cycle_length': 2048,  # 单个样本采样长度
            'target_length': 1024,  # 降采样后单个样本长度

            'time_window_size': 2048,  # 时域窗口样本尺寸
            'time_step_size': 256,     # 时域窗口滑窗步长

            'freq_window_size': 10240*2,  # 频域窗口样本尺寸
            'freq_step_size': 256,     # 频域窗口滑窗步长

            'total_samples': 200,  # 单类别总样本量
            'train_per_class': 100,  # 单类别训练样本量
            'test_per_class': 100,  # 单类别测试样本量

            'norm_type': 'minmax',  # 时域样本归一化方式：可选 'z-score'/'minmax'/'none'
            'window_type': 'none',  # 时域样本加窗方式：可选 'hann'/'hamming'/'none'

            'freq_analysis_type': 'envelope',  # 频域样本类型选择：可选'magnitude'常规幅度谱/'envelope'包络谱/'cepstrum'倒频谱
            'freq_norm_type': 'minmax',  # 频域样本归一化方式：可选 'z-score'/'minmax'/'none'
            'cepstrum_lifter': 0.8,  # 控制倒频谱的平滑程度，范围0-1（值越大，保留的低频成分越多）
            'sampling_rate': 51200,  # 信号的采样率（单位：Hz），要是降采样了要重新算一下

            'angular_resample_enabled': True,
            'angular_window_revs': 40,      # 角域窗口覆盖的圈数
            'angular_samples_per_rev': 1024,  # 每圈样本数
            'angular_step_revs': 1.0,         # 滑窗步长（圈数）
            'angular_norm_type': 'minmax',  # 角域样本归一化方式：可选 'z-score'/'minmax'/'none'

            'angular_freq_analysis_type': 'envelope',  # 角域频谱类型,# 频域样本类型选择：可选'magnitude'常规幅度谱/'envelope'包络谱
            'angular_freq_norm_type': 'none',  # 角域频谱样本归一化方式：可选 'z-score'/'minmax'/'none'

            'random_seed': 42,  # 新增：随机数种子
            'shuffle_split': True,  # 新增：是否随机划分训练测试集
            'shuffle_final': False,  # 新增：是否全局打乱训练集
            'save_path': './datasets/cached_SDUST/',  # 数据保存路径
            'use_cached': False,  # 是否使用原来的缓存

            'bearing_params': {  # mm,6205
                'inner_diameter': 25.0,
                'outer_diameter': 52.0,
                'ball_diameter': 7.94,
                'number_balls': 9,
                'contact_angle': 0
            },

        },

        'HNUST_6206': {
            'resample_enabled': False,  # bool: 是否启用降采样，要是是False就不用管下面两个参数
            'cycle_length': 2048,  # 单个样本采样长度
            'target_length': 1024,  # 降采样后单个样本长度

            'time_window_size': 2048,  # 时域窗口样本尺寸
            'time_step_size': 256,  # 时域窗口滑窗步长

            'freq_window_size': 10240 * 2,  # 频域窗口样本尺寸
            'freq_step_size': 256,  # 频域窗口滑窗步长

            'total_samples': 200,  # 单类别总样本量
            'train_per_class': 100,  # 单类别训练样本量
            'test_per_class': 100,  # 单类别测试样本量

            'norm_type': 'minmax',  # 时域样本归一化方式：可选 'z-score'/'minmax'/'none'
            'window_type': 'none',  # 时域样本加窗方式：可选 'hann'/'hamming'/'none'

            'freq_analysis_type': 'envelope',  # 频域样本类型选择：可选'magnitude'常规幅度谱/'envelope'包络谱/'cepstrum'倒频谱
            'freq_norm_type': 'minmax',  # 频域样本归一化方式：可选 'z-score'/'minmax'/'none'
            'cepstrum_lifter': 0.8,  # 控制倒频谱的平滑程度，范围0-1（值越大，保留的低频成分越多）
            'sampling_rate': 51200,  # 信号的采样率（单位：Hz），要是降采样了要重新算一下

            'angular_resample_enabled': True,
            'angular_window_revs': 40,  # 角域窗口覆盖的圈数
            'angular_samples_per_rev': 1024,  # 每圈样本数
            'angular_step_revs': 1.0,  # 滑窗步长（圈数）
            'angular_norm_type': 'minmax',  # 角域样本归一化方式：可选 'z-score'/'minmax'/'none'

            'angular_freq_analysis_type': 'envelope',  # 角域频谱类型,# 频域样本类型选择：可选'magnitude'常规幅度谱/'envelope'包络谱
            'angular_freq_norm_type': 'none',  # 角域频谱样本归一化方式：可选 'z-score'/'minmax'/'none'

            'random_seed': 42,  # 新增：随机数种子
            'shuffle_split': True,  # 新增：是否随机划分训练测试集
            'shuffle_final': False,  # 新增：是否全局打乱训练集
            'save_path': './datasets/cached_SDUST/',  # 数据保存路径
            'use_cached': False,  # 是否使用原来的缓存

            'bearing_params': {  # mm,6206
                'inner_diameter': 30.0,
                'outer_diameter': 62.0,
                'ball_diameter': 9.0,
                'number_balls': 9,
                'contact_angle': 0
            },

        },



    }

    def __init__(self, data_root, rpm=None):
        # self.data_root = data_root
        # self.dataset_type = self._detect_type()
        # self.params = self._presets[self.dataset_type].copy()
        # self.rpm = rpm or self._parse_rpm_from_path()  # 新增转速解析
        # self._validate_samples()
        # self._set_random_seed()
        # self._calc_angular_params()  # 新增动态参数计算

        self.data_root = data_root
        self.dataset_type = self._detect_type()
        self.params = self._presets[self.dataset_type].copy()

        # 动态处理转速逻辑
        self.rpm = rpm  # 先接受用户输入

        # CWRU/HNUST允许延迟加载rpm
        if self.rpm is None and self.dataset_type not in ['CWRU', 'HNUST_6204', 'HNUST_6205', 'HNUST_6206', 'HNUST_6207']:
            self.rpm = self._parse_rpm_from_path()

        # 此时rpm可能为None（对于CWRU/HNUST），需要后续加载数据后设置
        self._validate_samples()
        self._set_random_seed()

        # 延迟到实际加载数据后计算角域参数
        if self.rpm is not None:
            self._calc_angular_params()

    def update_rpm(self, rpm):
        """动态更新转速并重新计算参数"""
        self.rpm = rpm
        self._calc_angular_params()

    def _parse_rpm_from_path(self):
        """仅当非CWRU/HNUST时调用"""
        if self.dataset_type in ['CWRU', 'HNUST_6205', 'HNUST_6206']:
            return None  # 避免错误

        import re

    def _calc_angular_params(self):
        """动态计算角域参数（更新阶次计算）"""
        cfg = self.params

        # 原始计算
        samples_per_second = cfg['sampling_rate']
        seconds_per_rev = 60 / self.rpm
        cfg['samples_per_revolution'] = int(samples_per_second * seconds_per_rev)
        # 角域重采样参数
        cfg['angular_samples_per_rev'] = cfg['angular_samples_per_rev']  # 从配置获取
        cfg['angular_window_size'] = cfg['angular_window_revs'] * cfg['angular_samples_per_rev']
        cfg['angular_step_size'] = cfg['angular_step_revs'] * cfg['angular_samples_per_rev']


    def _parse_rpm_from_path(self):
        """尝试从文件路径解析转速"""
        import re
        match = re.search(r'(\d+)rpm', self.data_root, re.IGNORECASE)
        if match:
            return int(match.group(1))
        raise ValueError(
            f"未提供转速参数且路径中未检测到转速信息: {self.data_root}\n"
            f"请显式指定rpm参数或在路径中包含类似'1797rpm'的转速标识"
        )


    @property
    def data_type(self):
        """通过属性访问器获取data_type"""
        return self.params['data_type']  # 正确访问方式

    def _set_random_seed(self):
        """固定随机数种子"""
        np.random.seed(self.params['random_seed'])
        # 如需使用PyTorch可添加：
        # torch.manual_seed(self.params['random_seed'])

    def _detect_type(self):
        """根据实例属性识别数据集类型"""
        if 'cwru' in self.data_root.lower():
            return 'CWRU'
        elif 'hnust_6204' in self.data_root.lower():
            return 'HNUST_6204'
        elif 'hnust_6205' in self.data_root.lower():
            return 'HNUST_6205'
        elif 'hnust_6206' in self.data_root.lower():
            return 'HNUST_6206'
        elif 'hnust_6207' in self.data_root.lower():
            return 'HNUST_6207'
        elif 'hust' in self.data_root.lower():
            return 'HUST'
        elif 'sdust' in self.data_root.lower():
            return 'SDUST'
        elif '313' in self.data_root.lower():
            return 'LAB313'
        elif 'pdbu' in self.data_root.lower():
            return 'PDBU'
        elif 'jnu' in self.data_root.lower():
            return 'JNU'
        elif 'lab' in self.data_root.lower():
            return 'LAB'
        elif 'otta' in self.data_root.lower():
            return 'OTTA'
        elif 'hit' in self.data_root.lower():
            return 'HIT'
        else:
            # 添加更详细的错误提示
            sample_files = os.listdir(self.data_root)[:3]
            raise ValueError(
                f"无法识别数据集类型！路径中需要包含关键字\n"
                f"当前路径: {self.data_root}\n"
                f"目录示例文件: {sample_files}"
            )

    def _validate_samples(self):
        """验证样本数量设置"""
        if self.params['train_per_class'] + self.params['test_per_class'] != self.params['total_samples']:
            raise ValueError(
                f"样本数量不匹配! {self.params['train_per_class']}+{self.params['test_per_class']} != {self.params['total_samples']}")

    def _validate_preprocess(self):
        valid_norms = ['z-score', 'minmax', 'none']
        if self.params['norm_type'] not in valid_norms:
            raise ValueError(f"norm_type必须是 {valid_norms} 之一")

        valid_windows = ['hann', 'hamming', 'rectangular', 'none']
        if self.params['window_type'] not in valid_windows:
            raise ValueError(f"window_type必须是 {valid_windows} 之一")


class DataLoader:
    """修复后的数据加载器"""
    def __init__(self, config):
        self.config = config  # 保存配置信息

    def load_raw_data(self, file_path):
        """根据配置加载数据"""
        if self.config.dataset_type == 'CWRU':
            return self._load_cwru(file_path)
        elif self.config.dataset_type == 'HNUST_6205':
            return self._load_hnust(file_path)
        elif self.config.dataset_type == 'HNUST_6206':
            return self._load_hnust(file_path)
        else:
            raise ValueError("未知数据集类型")

    def _load_cwru(self, file_path):
        mat_data = sio.loadmat(file_path)
        key = [k for k in mat_data.keys() if '_DE_time' in k][0]
        key_RPM = [r for r in mat_data.keys() if 'RPM' in r][0]
        return {
            'data': mat_data[key].T.astype(np.float32),
            'rpm': mat_data[key_RPM].item()
        }

    def _load_hnust(self, file_path):
        mat_data = sio.loadmat(file_path)
        return {
            'data': mat_data['data'][:, 0].reshape(1, -1).astype(np.float32),
            'rpm': mat_data['fs'].item() * 60  # 转换为RPM
        }




class SignalValidator:
    """信号处理器（含严格样本控制）"""

    def __init__(self, config):
        self.cfg = config.params
        self.rpm = config.rpm  # 从配置获取动态转速


    def _calculate_fault_frequencies(self):
        """使用实例转速计算故障频率"""
        cfg = self.cfg
        bp = cfg['bearing_params']

        # 单位转换：毫米转米
        D = (bp['inner_diameter'] + bp['outer_diameter']) / 2000  # 转换为米
        d = bp['ball_diameter'] / 1000  # 转换为米
        n = bp['number_balls']
        alpha = bp['contact_angle']

        # 修正后的计算公式
        BPFI = n / 2 * (1 + (d / D) * np.cos(alpha)) * self.rpm / 60  # 内圈
        BPFO = n / 2 * (1 - (d / D) * np.cos(alpha)) * self.rpm / 60  # 外圈
        BSF = (D / (2 * d)) * (1 - (d / D * np.cos(alpha)) ** 2) * self.rpm / 60  # 滚珠

        return {
            'normal': 0,
            'BPFI': BPFI,
            'BPFO': BPFO,
            'BSF': BSF,
        }

    def _calculate_fault_order(self):
        """使用实例转速计算故障频率"""
        cfg = self.cfg
        bp = cfg['bearing_params']

        # 检查轴承参数是否存在
        required_params = ['inner_diameter', 'outer_diameter', 'ball_diameter', 'number_balls', 'contact_angle']
        for param in required_params:
            if param not in bp:
                raise ValueError(f"缺少轴承参数 '{param}'，无法计算故障阶次。")

        # 单位转换：毫米转米
        D = (bp['inner_diameter'] + bp['outer_diameter']) / 2000  # 转换为米
        d = bp['ball_diameter'] / 1000  # 转换为米
        n = bp['number_balls']
        alpha = np.deg2rad(bp['contact_angle'])  # 将接触角转换为弧度

        # 计算故障特征阶次
        BPFI_order = n / 2 * (1 + (d / D) * np.cos(alpha))
        BPFO_order = n / 2 * (1 - (d / D) * np.cos(alpha))
        BSF_order = (D / (2 * d)) * (1 - (d / D * np.cos(alpha)) ** 2)

        return {
            'normal': 0,
            'BPFI': BPFI_order,
            'BPFO': BPFO_order,
            'BSF': BSF_order,
        }


    def process(self, raw_data_dict):
        """处理包含数据和转速的字典"""
        raw_data = raw_data_dict['data']
        rpm = raw_data_dict['rpm']

        # 时域处理
        time_processed = self._process_time_domain(raw_data)

        # 角域处理
        angular_processed, angular_processed_nonnorm = self._process_angular_domain(raw_data, rpm)

        # 频域处理
        freq_processed = self._process_freq_domain(raw_data)

        # 角域频域处理
        angular_freq_processed = self._process_angular_freq(angular_processed_nonnorm)

        return {
            'time': time_processed,
            'angular': angular_processed,
            'freq': freq_processed,
            'angular_freq': angular_freq_processed
        }


    def _process_time_domain(self, raw_data):
        """时域专用处理流"""
        # 条件降采样
        if self.cfg['resample_enabled']:
            data = self._resample(raw_data)
        else:
            data = raw_data
        # 验证时域数据长度
        self._validate_domain_length(data, is_time_domain=True)
        # 生成时域窗口
        windows = self._sliding_window(
            data,
            self.cfg['time_window_size'],
            self.cfg['time_step_size']
        )
        norm_type = self.cfg['norm_type']
        # 时域后续处理
        return self._normalize(windows, norm_type, 2)

    def _process_angular_domain(self, raw_data, rpm):
        """角域处理逻辑：固定每窗口圈数，滑动生成多样本"""
        if not self.cfg['angular_resample_enabled']:
            return np.array([])
        # 1. 获取配置参数
        cfg = self.cfg
        original_sr = cfg['sampling_rate']
        window_revs = cfg['angular_window_revs']  # 每个窗口覆盖的圈数（如5）
        samples_per_rev = cfg['angular_samples_per_rev']  # 每圈样本数（如1024）
        step_revs = cfg.get('angular_step_revs', 1)  # 滑动步长（圈数，默认1）
        # 2. 计算原始累计角度
        time_axis = np.arange(raw_data.shape[1]) / original_sr
        original_angles = (rpm / 60) * 360 * time_axis  # 单位：度
        # 3. 计算总可用圈数（向下取整）
        total_revs = int(original_angles[-1] // 360)
        if total_revs < window_revs:
            raise ValueError(f"数据不足：需至少{window_revs}圈，实际{total_revs}圈")
        # 4. 生成覆盖所有圈数的目标角度序列
        target_angles = np.linspace(0, total_revs * 360,
                                    total_revs * samples_per_rev,
                                    endpoint=False)
        # 5. 截取原始数据到总圈数对应的时间点
        end_time = (total_revs * 60) / rpm  # 总时间 = 总圈数 * 每圈时间
        end_index = int(end_time * original_sr)
        raw_data_truncated = raw_data[:, :end_index]
        original_angles_truncated = (rpm / 60) * 360 * (np.arange(end_index) / original_sr)
        # 6. 角度重采样（外推）
        interpolator = interp1d(
            original_angles_truncated,
            raw_data_truncated,
            axis=1,
            kind='linear',
            bounds_error=False
        )
        angular_data = interpolator(target_angles)
        # 7. 计算滑动窗口参数
        window_size = int(window_revs * samples_per_rev)  # 单窗口样本数
        step_size = int(step_revs * samples_per_rev)  # 滑动步长（样本数）
        # 8. 应用滑动窗口
        windows = self._sliding_window(
            angular_data,
            window_size=window_size,
            step_size=step_size
        )
        norm_type = self.cfg['angular_norm_type']

        # 9. 时域预处理
        return self._normalize(windows, norm_type, 2), windows

    def _process_angular_freq(self, angular_data):
        if angular_data is None:
            return None
        # 根据配置选择频谱类型
        norm_type = self.cfg['angular_freq_norm_type']
        if self.cfg['angular_freq_analysis_type'] == 'magnitude':
            processed = np.abs(np.fft.rfft(angular_data, axis=2))/(angular_data.shape[2]/2) #################################3
            processed[:, :, 0] = 0
            return self._normalize(processed, norm_type, 2)
        elif self.cfg['angular_freq_analysis_type'] == 'envelope':
            processed = self._compute_envelope_spectrum(angular_data)
            processed[:, :, 0] = 0
            return self._normalize(processed, norm_type, 2)
        else:
            raise ValueError(f"Unsupported angular spectrum type: {self.cfg['angular_freq_analysis_type']}")


    def _process_freq_domain(self, raw_data):
        """频域专用处理流（始终使用原始数据）"""
        # 验证频域数据长度
        self._validate_domain_length(raw_data, is_time_domain=False)
        # 生成频域窗口
        windows = self._sliding_window(
            raw_data,
            self.cfg['freq_window_size'],
            self.cfg['freq_step_size']
        )
        norm_type = self.cfg['freq_norm_type']
        # 频域后续处理
        return self._process_freq(windows, norm_type)

    def _process_freq(self, windows, norm_type):
        """频域信号处理方法（根据配置选择方法）"""
        if self.cfg['freq_analysis_type'] == 'magnitude':
            processed = np.abs(np.fft.rfft(windows, axis=2))/(windows.shape[2]/2) #################################3
            processed[:, :, 0] = 0  # 直流分量置零
        elif self.cfg['freq_analysis_type'] == 'envelope':
            processed = self._compute_envelope_spectrum(windows)
            processed[:, :, 0] = 0
        elif self.cfg['freq_analysis_type'] == 'cepstrum':
            processed = self._compute_cepstrum(np.fft.rfft(windows, axis=2))
        else:
            raise ValueError(f"不支持的频域分析类型: {self.cfg['freq_analysis_type']}")
        return self._normalize(processed, norm_type, 2)

    def _validate_domain_length(self, data, is_time_domain):
        """分域验证数据长度"""
        cfg = self.cfg
        if is_time_domain:
            required = cfg['time_step_size'] * (cfg['total_samples'] - 1) + cfg['time_window_size']
            domain = '时域'
        else:
            required = cfg['freq_step_size'] * (cfg['total_samples'] - 1) + cfg['freq_window_size']
            domain = '频域'

        if data.shape[1] < required:
            raise ValueError(
                f"{domain}数据长度不足！需要{required}点，实际{data.shape[1]}点\n"
                f"建议调整：{'time' if is_time_domain else 'freq'}_step_size参数"
            )

    def _sliding_window(self, data, window_size, step_size, check=False):
        """通用滑动窗口生成"""
        if check and data.shape[1] < window_size:
            return np.array([])

        windows = np.lib.stride_tricks.sliding_window_view(data, window_size, axis=1)
        return windows[..., ::step_size, :].transpose(1, 0, 2)

    def _resample(self, data):
        """时域专用降采样方法"""
        original_length = data.shape[1]
        target_length = int(original_length * self.cfg['target_length'] / self.cfg['cycle_length'])
        return signal.resample(data, target_length, axis=1)

    def _normalize(self, data, norm_type, axis):
        """通用标准化方法"""
        if norm_type == 'z-score':
            return (data - np.mean(data, axis=axis, keepdims=True)) / np.std(data, axis=axis, keepdims=True)
        elif norm_type == 'minmax':
            data_min = np.min(data, axis=axis, keepdims=True)
            data_max = np.max(data, axis=axis, keepdims=True)
            return (data - data_min) / (data_max - data_min + 1e-8)
        return data

    def _compute_envelope_spectrum(self, time_data):
        """包络谱通用计算"""
        analytic_signal = signal.hilbert(time_data, axis=2)
        return np.abs(np.fft.rfft(np.abs(analytic_signal), axis=2)/(time_data.shape[2]/2)) #################################3

    def _compute_cepstrum(self, fft_data):
        """倒谱计算"""
        log_power = np.log(np.abs(fft_data)**2 + 1e-8)
        cepstrum = np.fft.irfft(log_power, axis=2)
        quefrency = np.arange(cepstrum.shape[2]) / self.cfg['sampling_rate']
        return cepstrum * np.exp(-self.cfg['cepstrum_lifter'] * quefrency)

    def _validate_data_length(self, data, window_size, step_size, domain_name):
        """数据长度验证"""
        required_length = step_size * (self.cfg['total_samples'] - 1) + window_size
        if data.shape[1] < required_length:
            raise ValueError(
                f"{domain_name}域数据不足：需要{required_length}点，实际{data.shape[1]}点\n"
                f"建议调整 {domain_name}_step_size 参数"
            )








class DatasetBuilder:
    def __init__(self, config):
        self.config = config
        self.validator = SignalValidator(config)
        self.loader = DataLoader(config)

    def build(self):
        # 获取缓存路径
        save_dir = Path(self.config.params["save_path"])
        save_dir.mkdir(parents=True, exist_ok=True)

        # 对于CWRU/HNUST，需要先加载一个文件获取实际rpm
        if self.config.rpm is None and self.config.dataset_type in ['CWRU', 'HNUST_6204', 'HNUST_6205', 'HNUST_6206', 'HNUST_6207']:
            sample_file = next(f for f in os.listdir(self.config.data_root) if f.endswith('.mat'))
            sample_path = os.path.join(self.config.data_root, sample_file)
            raw_data = self.loader.load_raw_data(sample_path)
            self.config.update_rpm(raw_data['rpm'])  # 动态更新转速

        # 重新生成数据集
        print("生成新数据集...")
        dataset = self._build_from_scratch()
        dataset['fault_frequencies'] = self._calculate_fault_frequencies()
        dataset['fault_orders'] = self._calculate_fault_orders()
        return dataset

    def _calculate_fault_frequencies(self):
        """计算故障特征频率"""
        validator = SignalValidator(self.config)
        return validator._calculate_fault_frequencies()

    def _calculate_fault_orders(self):
        """计算故障特征频率"""
        validator = SignalValidator(self.config)
        return validator._calculate_fault_order()


    def _build_from_scratch(self):
        """支持多类型数据的原始构建逻辑"""
        dataset = {
            'train': {'time': [], 'freq': [], 'angular':[], 'angular_freq':[], 'labels':[]},
            'test': {'time': [], 'freq': [], 'angular':[], 'angular_freq':[], 'labels':[]}
        }

        data_files = sorted([
            f for f in os.listdir(self.config.data_root)
        ])
        print(f"发现 {len(data_files)} 个数据文件")

        # 统一文件处理流程
        for label, data_file in enumerate(data_files):
            file_path = os.path.join(self.config.data_root, data_file)
            print(f"\n处理文件 {label + 1}/{len(data_files)}: {data_file}")

            try:
                class_data = self._process_single_file(file_path, label)
                self._merge_dataset(dataset, class_data)

            except Exception as e:
                print(f"! 文件处理失败: {data_file}\n错误信息: {str(e)}")
                continue

        return self.finalize(dataset)

    def _process_single_file(self, file_path, label):
        raw_data_dict = self.loader.load_raw_data(file_path)
        features = self.validator.process(raw_data_dict)

        # 获取各域数据
        actual_samples = min(
            features['time'].shape[0],
            features['angular'].shape[0] if features['angular'] is not None else float('inf'),
            self.config.params['total_samples']
        )
        time_data = features['time'][:actual_samples]
        freq_data = features['freq'][:actual_samples]
        angular_data = features['angular'][:actual_samples]
        angular_freq_data = features['angular_freq'][:actual_samples]

        # 样本划分
        indices = np.random.permutation(actual_samples) if self.config.params['shuffle_split'] else np.arange(
            actual_samples)
        split_point = self.config.params['train_per_class']

        return {
            'train': {
                'time': time_data[indices[:split_point]],
                'freq': freq_data[indices[:split_point]],
                'angular': angular_data[indices[:split_point]],
                'angular_freq': angular_freq_data[indices[:split_point]],
                'labels': np.full(split_point, label)
            },
            'test': {
                'time': time_data[indices[split_point:]],
                'freq': freq_data[indices[split_point:]],
                'angular': angular_data[indices[split_point:]],
                'angular_freq': angular_freq_data[indices[split_point:]],
                'labels': np.full(actual_samples - split_point, label)
            }
        }

    def _merge_dataset(self, main_ds, class_ds):
        for split in ['train', 'test']:
            for key in ['time', 'freq', 'angular', 'angular_freq']:
                main_ds[split][key].append(class_ds[split][key])
            main_ds[split]['labels'].append(class_ds[split]['labels'])

    def finalize(self, dataset):
        final_ds = {
            'train': {
                'time': np.concatenate(dataset['train']['time'], axis=0),
                'freq': np.concatenate(dataset['train']['freq'], axis=0),
                'angular': np.concatenate(dataset['train']['angular'], axis=0),
                'angular_freq': np.concatenate(dataset['train']['angular_freq'], axis=0),
                'labels': np.concatenate(dataset['train']['labels'], axis=0)
            },
            'test': {
                'time': np.concatenate(dataset['test']['time'], axis=0),
                'freq': np.concatenate(dataset['test']['freq'], axis=0),
                'angular': np.concatenate(dataset['test']['angular'], axis=0),
                'angular_freq': np.concatenate(dataset['test']['angular_freq'], axis=0),
                'labels': np.concatenate(dataset['test']['labels'], axis=0)
            }
        }
        # 新增频率轴计算
        window_size = self.config.params['freq_window_size']
        sampling_rate = self.config.params['sampling_rate']
        final_ds['freq_axis'] = np.fft.rfftfreq(window_size, 1 / sampling_rate)
        # 生成角域阶次轴
        cfg = self.config.params
        window_size = cfg['angular_window_size']
        samples_per_rev = cfg['angular_samples_per_rev']
        final_ds['orders_axis'] = np.fft.rfftfreq(window_size) * samples_per_rev

        # 关键修改：去除中间的单维度
        for split in ['train', 'test']:
            final_ds[split]['time'] = final_ds[split]['time'].squeeze(axis=1)
            final_ds[split]['freq'] = final_ds[split]['freq'].squeeze(axis=1)
            final_ds[split]['angular'] = final_ds[split]['angular'].squeeze(axis=1)
            final_ds[split]['angular_freq'] = final_ds[split]['angular_freq'].squeeze(axis=1)

        return final_ds








