import torch.optim as optim
import random
from model import *
from data_set import *
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
from torch.optim.lr_scheduler import CosineAnnealingLR

class Config:
    def __init__(self):
        # 实验配置
        self.experiment = {
            'domains': ['all_data'],  # 数据集设置
            'result_filename': 'ep100_rs1000_zero_6_3_w24'
        }

        # 数据路径配置，遍历训练+测试
        self.data_paths = {

            'all_data': [

                r'.\bearing_cwru\data_007_0',
                r'.\bearing_cwru\data_007_1',
                r'.\bearing_cwru\data_007_2',

                r'.\bearing_cwru\data_021_0',
                r'.\bearing_cwru\data_021_1',
                r'.\bearing_cwru\data_021_2',

                r'.\bearing_hnust_6205\6205_000w',
                r'.\bearing_hnust_6205\6205_200w',
                r'.\bearing_hnust_6205\6205_400w',

                r'.\bearing_hnust_6206\6206_000w',
                r'.\bearing_hnust_6206\6206_200w',
                r'.\bearing_hnust_6206\6206_400w',

            ],

        }

        # 训练参数
        self.training = {
            'epochs': 50,
            'batch_size': 200,
            'run_times': 3,
            'base_seed': 0,  # 初始种子值
            'seed_increment': 1000,  # 每次运行的种子增量
        }

        # 优化器参数
        self.optimizer = {
            'type': 'AdamW',
            'lr': 1e-4,
            'weight_decay': 1e-5,
            'betas': (0.9, 0.999)
        }

        # 模型参数
        self.model = {
            'num_classes': 3,
            'scheduler': 'CosineAnnealingLR',
            'scheduler_params': {
                'T_max': 1000,  # 实际值在代码中动态计算
                'eta_min': 1e-4
            }
        }

    def get_test_paths(self, domain):
        return self.data_paths.get(domain, [])



# 初始化配置实例
cfg = Config()




def randomseed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)




import torch
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader


from torch.utils.data import TensorDataset, ConcatDataset


def train_model(source_data, model_no, current_seed, cfg):
    randomseed(current_seed)
    model = BaseModel(cfg.model['num_classes']).to(device)

    all_x = []
    all_y = []
    all_anti_x = []
    all_anti_y = []

    for case_name, (x, y, anti_x, anti_y) in source_data.items():  # 元组解包
        all_x.append(x)
        all_y.append(y)
        all_anti_x.append(anti_x)
        all_anti_y.append(anti_y)

    # 合并多个案例的数据
    combined_x = np.vstack(all_x)  # 垂直堆叠数组
    combined_y = np.concatenate(all_y)  # 连接数组
    combined_anti_x = np.vstack(all_anti_x)
    combined_anti_y = np.concatenate(all_anti_y)

    x_tensor = torch.from_numpy(combined_x).float()
    y_tensor = torch.from_numpy(combined_y).long()

    #反事实样本、增强样本去除未更改的正常样本
    combined_anti_y[100:] = 0

    anti_x_tensor = torch.from_numpy(combined_anti_x[100:, :]).float()
    anti_y_tensor = torch.from_numpy(combined_anti_y[100:]).long()

    dataset = TensorDataset(x_tensor.to(device), y_tensor.to(device))
    anti_dataset = TensorDataset(anti_x_tensor.to(device), anti_y_tensor.to(device))

    # 创建DataLoader
    train_loader = DataLoader(
        dataset,
        batch_size=cfg.training['batch_size'],  # 确认配置参数名一致
        shuffle=True,
    )
    anti_train_loader = DataLoader(
        anti_dataset,
        batch_size=cfg.training['batch_size'],  # 确认配置参数名一致
        shuffle=True,
    )


    # 主模型优化器
    optimizer_main = getattr(optim, cfg.optimizer['type'])(
        model.parameters(),
        lr=cfg.optimizer['lr'],
        weight_decay=cfg.optimizer['weight_decay'],
        betas=cfg.optimizer['betas']
    )


    model.train()
    # 学习率调度器
    total_steps = cfg.training['epochs'] * len(train_loader)
    scheduler_main = CosineAnnealingLR(optimizer_main, T_max=total_steps*2, eta_min=1e-6)

    for epoch in range(cfg.training['epochs']):
        model.train()
        # for batch_x, batch_y in train_loader:
        for batch_dataset, batch_anti_dataset in zip(train_loader, anti_train_loader):
            batch_x, batch_y = batch_dataset
            batch_anti_x, batch_anti_y = batch_anti_dataset

            # 前向传播获取结构化特征
            feats, preds_nomask = model(batch_x, anti=False)
            anti_feats, anti_preds_nomask = model(batch_anti_x, anti=True)


            # 初始化总损失
            total_loss = 0.0
            # 计算分类损失
            cls_loss_main = F.cross_entropy(preds_nomask, batch_y)
            anti_cls_loss = F.cross_entropy(anti_preds_nomask, batch_anti_y)



            total_loss += (cls_loss_main+anti_cls_loss)

            print(f"Epoch {epoch + 1}/{cfg.training['epochs']}, "
                  f"Loss_cls: {(cls_loss_main).item():.4f},  "
                  f"Loss_anti_cls: {anti_cls_loss.item():.4f} " )
                  # f"Loss_anti_cls: {anti_cls_loss.item():.4f}, Loss_syn_cls: {syn_cls_loss.item():.4f} " )
            # 反向传播
            optimizer_main.zero_grad()
            total_loss.backward()
            optimizer_main.step()
            scheduler_main.step()

    torch.save(model.state_dict(), f"model_{model_no}.pth")


def test_model(test_x, test_y, model_no, cfg, count_train, count_test):
    # 在训练代码中创建模型时
    model_test = BaseModel(
        num_classes=cfg.model['num_classes'],
    ).to(device)
    model_test.load_state_dict(torch.load(f"model_{model_no}.pth", weights_only=True))
    model_test.eval()

    # 转换为张量
    test_x = torch.tensor(test_x, dtype=torch.float32).to(device)
    test_y = torch.tensor(test_y, dtype=torch.long).to(device).squeeze()

    # 直接使用原始前向传播
    with torch.no_grad():
        _, logits = model_test(test_x, anti=False)

    # 计算准确率
    accuracy = (logits.argmax(dim=1) == test_y).float().mean()
    print(f"Model {model_no} Test Accuracy: {accuracy.item():.2%}")

    return accuracy.item()



##############################################################################
import pandas as pd
from generate_bearing_fault_angular import apply_advanced_masking

# 定义不同故障类型的谐波配置，以进行反样本与增强样本构造
fault_harmonics_config = {
    'BPFI': 6,   # BPFI故障考虑N阶谐波
    'BPFO': 3,   # BPFO故障考虑N阶谐波
    'BSF': 3     # BSF故障考虑N阶谐波
}

# 在文件顶部添加以下导入
import hashlib
import os

# 添加缓存目录配置
CACHE_DIR = "./data_cache_zero_6_3_24"
os.makedirs(CACHE_DIR, exist_ok=True)

def get_cache_filename(case_path):
    """生成唯一的缓存文件名"""
    # 创建路径的哈希值
    hash_obj = hashlib.md5(case_path.encode())
    return f"cached_{hash_obj.hexdigest()}.npz"


def load_case_data(case_path):
    """带缓存的数据加载函数"""
    cache_file = os.path.join(CACHE_DIR, get_cache_filename(case_path))

    # 如果缓存存在则直接加载
    if os.path.exists(cache_file):
        print(f"Loading cached data from {cache_file}")
        data = np.load(cache_file)
        return (
            data['train_x'], data['train_y'],
            data['test_x'], data['test_y'],
            data['train_anti_x'], data['train_anti_y'],
        )
    """加载单个工况的数据，包含反样本构造，增强样本构造"""
    data_lenght = 2048


    # 加载原始数据
    real_data = DatasetBuilder(DatasetConfig(case_path)).build()

    # 归一化原始训练测试集
    train_x = real_data['train']['angular_freq'][:, :data_lenght]
    test_x = real_data['test']['angular_freq'][:, :data_lenght]
    train_y = real_data['train']['labels']
    test_y = real_data['test']['labels']

    # 生成并归一化反事实样本
    anti_data = apply_advanced_masking(
        real_data,
        fault_harmonics=fault_harmonics_config,
        mask_type='zero'
    )
    train_anti_x = anti_data['train']['angular_freq'][:, :data_lenght]
    train_anti_y = anti_data['train']['labels']


    # 保存处理结果到缓存
    np.savez_compressed(
        cache_file,
        train_x=train_x, train_y=train_y,
        test_x=test_x, test_y=test_y,
        train_anti_x=train_anti_x, train_anti_y=train_anti_y,
    )
    print(f"Saved processed data to {cache_file}")

    return train_x, train_y, test_x, test_y, train_anti_x, train_anti_y

# 在main函数前添加缓存版本控制（可选）
CACHE_VERSION = "v1"  # 当数据处理逻辑变化时修改版本号

def get_cache_filename(case_path):
    """带版本控制的缓存文件名"""
    hash_obj = hashlib.md5(case_path.encode())
    return f"cached_{CACHE_VERSION}_{hash_obj.hexdigest()}.npz"

import os


def extract_case_id(path):
    """智能工况标识提取函数"""
    # 步骤1：提取域名 (如从 'bearing_lab' 中提取 'lab')
    path_parts = path.split(os.sep)
    domain_part = [p for p in path_parts if p.startswith('bearing_')][0]
    domain = domain_part.split('_', 1)[1]  # 分割一次获取正确域名
    # 步骤2：提取工况特征
    case_dir = os.path.basename(path)  # 获取路径最后一段
    # 步骤3：根据域名的智能格式化
    if domain == 'lab' or 'hust':
        # lab域案例：直接使用转速信息，如 1800rpm → lab_1800rpm
        case_id = f"{domain}_{case_dir}"
    elif domain == 'otta':
        # otta域案例：转换 com_2 → com2
        if '_' in case_dir:
            prefix, num = case_dir.split('_')
            case_id = f"{domain}_{prefix}{num}"
        else:
            case_id = f"{domain}_{case_dir}"
    else:
        # 通用处理：保留最后两段特征，如 data_007_0 → 007_0
        parts = case_dir.split('_')
        case_feature = '_'.join(parts[-2:]) if len(parts) >= 2 else case_dir
        case_id = f"{domain}_{case_feature}"
    return case_id


def load_all_cases():
    """加载所有工况数据（自动划分训练测试）"""
    case_data = {'source': {}, 'target': {}}
    # 加载源域所有工况
    for domain in cfg.experiment['domains']:
        for case_path in cfg.data_paths[domain]:
            case_id = f"{domain}_{extract_case_id(case_path)}"
            train_x, train_y, test_x, test_y, train_anti_x, train_anti_y = load_case_data(case_path)
            case_data['source'][case_id] = (train_x, train_y, train_anti_x, train_anti_y)
            case_data['target'][case_id] = (test_x, test_y)

    return case_data


def main():
    case_data = load_all_cases()
    results = []
    count_train = 0
    # 遍历所有源工况
    for src_id, src_data in case_data['source'].items():
        print(f"\n=== 训练源工况: {src_id} ===")
        # 运行多次实验
        run_records = {tgt_id: [] for tgt_id in case_data['target']}
        for run in range(cfg.training['run_times']):
            current_seed = cfg.training['base_seed'] + run * cfg.training['seed_increment']
            randomseed(current_seed)

            # 训练模型
            train_model({src_id: src_data}, run, current_seed, cfg)
            count_test = 0

            # 测试所有目标工况
            for tgt_id, (x_test, y_test) in case_data['target'].items():
                acc = test_model(x_test, y_test, run, cfg, count_train, count_test)
                count_test += 1
                run_records[tgt_id].append(acc)
                print(f"源工况 [{src_id}] → 目标工况 [{tgt_id}] 准确率: {acc:.2%}")
        count_train += 1

        # 记录详细结果
        for tgt_id, acc_list in run_records.items():
            result_row = {
                '训练工况': src_id,
                '测试工况': tgt_id,
             ** {f'Run {i + 1}': acc for i, acc in enumerate(acc_list)},
            '平均值': np.mean(acc_list),
            '标准差': np.std(acc_list, ddof=1)
            }
            results.append(result_row)

    # 创建详细数据表格
    detail_df = pd.DataFrame(results)

    # 创建透视表格（包含所有运行数据）
    pivot_cols = [f'Run {i + 1}' for i in range(cfg.training['run_times'])] + ['平均值', '标准差']
    pivot_df = detail_df.pivot_table(
        index='训练工况',
        columns='测试工况',
        values=pivot_cols,
        aggfunc='first'  # 因为数据已经预先聚合
    )

    # 调整列名层级
    pivot_df.columns = pivot_df.columns.swaplevel(0, 1)
    pivot_df = pivot_df.sort_index(axis=1, level=0)

    # 保存结果
    output_path = f"{cfg.experiment['result_filename']}_完整结果.xlsx"
    with pd.ExcelWriter(output_path) as writer:
        detail_df.to_excel(writer, sheet_name='详细数据', index=False)
        pivot_df.to_excel(writer, sheet_name='透视汇总')

    print(f"结果已保存至: {output_path}")



if __name__ == "__main__":
    main()






