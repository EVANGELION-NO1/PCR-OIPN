import torch.nn as nn
import torch

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout = 0.):
        super().__init__()

        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self, dim, heads=8, dim_head=64, dropout=0.):
        super().__init__()
        inner_dim = dim_head * heads
        project_out = not (heads == 1 and dim_head == dim)

        # 保留核心注意力结构
        self.heads = heads
        self.scale = dim_head  **  -0.5
        self.norm = nn.LayerNorm(dim)
        self.attend = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(dropout)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)
        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()
        self.attn_weights = None  # 存储注意力权重
        self.qk_matrix = None  # 存储QK矩阵

    def forward(self, x):
        x = self.norm(x)
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h=self.heads), qkv)

        # 计算QK矩阵
        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale
        self.qk_matrix = dots.detach().cpu().numpy()  # 保存QK矩阵

        attn = self.attend(dots)
        self.attn_weights = attn.detach().cpu().numpy()  # 保存注意力权重
        attn = self.dropout(attn)
        out = torch.matmul(attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)


class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, mlp_dim, dropout=0.):
        super().__init__()
        self.layers = nn.ModuleList([])
        # 添加属性存储中间输出
        self.attention_outputs = [None] * depth
        self.ffn_outputs = [None] * depth

        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Attention(dim, heads=heads, dim_head=dim_head, dropout=dropout),
                FeedForward(dim, mlp_dim, dropout=dropout)
            ]))

    def forward(self, x):
        for idx, (attn, ff) in enumerate(self.layers):
            # 保存注意力输出
            attn_out = attn(x)
            self.attention_outputs[idx] = attn_out.detach().cpu().numpy()
            x = attn_out + x

            # 保存FFN输出
            ffn_out = ff(x)
            self.ffn_outputs[idx] = ffn_out.detach().cpu().numpy()
            x = ffn_out + x
        return x


import torch
import torch.nn as nn
from einops import rearrange


class FeatureExtractor(nn.Module):
    def __init__(self, dim=256):
        super().__init__()

        self.Econv0 = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=64, kernel_size=15, stride=4, padding=7), #51-25 101-50
            nn.InstanceNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2, 2),
        )

        # 调整Transformer参数与dim一致
        self.transformer = Transformer(
            dim=dim,  # 关键修改：使用统一维度
            depth=6,
            heads=8,
            dim_head=256,
            mlp_dim=512,
        )
        self.mlp_head = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, 3)
        )
        self.pool = nn.AdaptiveAvgPool1d(1)  # 将[N,dim] → [1,dim]
        self.conv_output = None
        self.conv_hook = None

        # 添加钩子相关变量
        self.conv_output = None
        self.conv_hook = None
        self.transformer_hooked = False

    def register_transformer_hooks(self):
        """注册钩子捕获Transformer中间输出"""

        def hook(module, input, output):
            pass

        # 标记已注册钩子
        self.transformer_hooked = True

    def register_hook(self):
        """注册钩子以捕获卷积输出"""

        def hook(module, input, output):
            self.conv_output = output.detach().cpu()

        if self.Econv0[0] is not None:
            self.conv_hook = self.Econv0[0].register_forward_hook(hook)

    def remove_hook(self):
        """移除钩子"""
        if self.conv_hook is not None:
            self.conv_hook.remove()

    def forward(self, x):
        # 清除之前的输出
        self.conv_output = None

        # 原始输入处理
        x = torch.unsqueeze(x, dim=1)  # [B,N] → [B,1,N]

        # 应用卷积层
        conv_out = self.Econv0[0](x)  # 单独获取卷积输出

        # 继续后续处理
        x = self.Econv0[1](conv_out)  # InstanceNorm
        x = self.Econv0[2](x)  # ReLU
        x = self.Econv0[3](x)  # MaxPool
        # 特征提取
        if not self.transformer_hooked:
            self.register_transformer_hooks()
        # 特征提取
        features = self.transformer(x)
        features = self.pool(features.transpose(1, 2)).squeeze(-1)
        cls = self.mlp_head(features)

        return features, cls

from typing import List, Optional, Dict, Any
import torch.nn as nn

class BaseModel(nn.Module):
    def __init__(self,
                 num_classes: int,
                 feature_dim: int = 256,
                 dropout_rate: float = 0.2):

        super().__init__()
        # 共享特征提取器
        self.feature_extractor = FeatureExtractor()

    def _hook_conv_features(self, features):
        """捕获最后一个卷积层的特征"""
        self.conv_features = features.detach()

    def forward(self, x, anti):
        '''浅层特征，特征正向，特征反向，特征'''
        feats, cls = self.feature_extractor(x)
        return feats, cls


